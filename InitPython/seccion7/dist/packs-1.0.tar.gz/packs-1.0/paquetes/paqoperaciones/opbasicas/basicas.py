def suma(a1, a2):
	print("La suma es: ", a1 + a2)

def resta(a1, a2):
	print("La resta es: ", a1 - a2)

def multiplicacion(a1, a2):
	print("La multiplicación es: ", a1 * a2)

def division(a1, a2):
	print("La división es: ", a1 / a2)