# from nombre_paquete.nombre_modulo import nombre_funcion
# from paqoperaciones.operaciones import *

from paqoperaciones.opbasicas.basicas import multiplicacion

multiplicacion(4,8)

from paqoperaciones.opotros.otros import redondeo

redondeo(9.4)