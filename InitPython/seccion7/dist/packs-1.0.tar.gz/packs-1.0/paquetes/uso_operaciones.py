# from nombre_paquete.nombre_modulo import nombre_funcion
# from paqoperaciones.operaciones import *
from paqoperaciones.operaciones import suma, resta, multiplicacion, division

resta(34,76)
suma(12,8)
multiplicacion(9,19)
division(90,5)