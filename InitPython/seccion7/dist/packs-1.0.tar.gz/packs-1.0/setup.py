from setuptools import setup

setup(
	name = "packs",
	version = "1.0",
	description = "Operaciones Matemáticas Básicas",
	author = "Tutocodev",
	url = "tutocodev.teachable.com",
	packages = ["paquetes","paquetes.paqoperaciones.opbasicas"]
)